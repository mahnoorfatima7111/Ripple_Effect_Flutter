import 'package:flutter/material.dart';

class CloveClub extends StatefulWidget {
  const CloveClub({super.key});

  @override
  State<CloveClub> createState() => _CloveClubState();
}

class _CloveClubState extends State<CloveClub> {
  @override
  Widget build(BuildContext context) {
    var size = MediaQuery.of(context).size;
    var width = size.width;
    var height = size.height;
    var containerWidth = width * 0.2;
    var containerHeight = height * 0.9;

    return SizedBox(
      width: width * 0.7,
      height: height * 0.9,
      child: Row(
        children: [
          Container(
            width: containerWidth,
            height: containerHeight,
            decoration: BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/images/background.jpg'),
                fit: BoxFit.cover,
              ),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Image.asset(
                  'assets/images/logo.png',
                  // height: containerHeight,
                ),
                // SizedBox(height: 0),
                Transform.translate(
                  offset: Offset(0, -containerHeight * 0.04), // move text up
                  child: Text(
                    "Clover Club",
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 17,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Stack(
          //   children: <Widget>[
          //     // Image.asset(
          //     //   'assets/images/background.jpg',
          //     //   fit: BoxFit.cover,
          //     // ),
          //     // Positioned(
          //     //   height: containerHeight,
          //     //   width: containerWidth,
          //     //   child: Image.asset(
          //     //     'assets/images/background.jpg',
          //     //     fit: BoxFit.cover,
          //     //   ),
          //     // ),
          //     Positioned(
          //       // top: containerHeight * 0.01,
          //       left: containerWidth * 0.02,
          //       height: containerHeight,
          //       width: containerWidth,
          //       child: Image.asset('assets/images/logo.png'),
          //     ),
          //     // Positioned(child: child),
          //   ],
          // ),
          // ),
        ],
      ),
    );
  }
}



//  Scaffold(
//       backgroundColor: Color.fromARGB(255, 216, 230, 224),

//       // appBar: AppBar(
//       //   backgroundColor: Theme.of(context).colorScheme.inversePrimary,
//       //   leading: Image(image: AssetImage("assets/images/logo.png")),
//       //   title: Text(widget.title),
//       // ),
//       body: Center(
//         child: SizedBox(
          
//         ),
//       ),
//       // floatingActionButton: FloatingActionButton(
//       //   onPressed: _incrementCounter,
//       //   tooltip: 'Increment',
//       //   child: const Icon(Icons.add),
//       // ),
//     );