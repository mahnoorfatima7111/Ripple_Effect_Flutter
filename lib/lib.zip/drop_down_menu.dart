import 'dart:math';
import 'package:flutter/material.dart';

class DropDownMenu extends StatelessWidget {
  const DropDownMenu({super.key});

  @override
  Widget build(BuildContext context) {
    final List<String> dropDownItems = [
      'Option 1',
      'Option 2',
      'Option 3',
      'Option 4',
      'Option 5',
      'Option 6',
      'Option 7',
      'Option 8',
    ];

    return Scaffold(
      body: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          // Padding(
          //   padding: const EdgeInsets.all(8.0),
          //   child:
          AnimatedDropDown(
            items: dropDownItems,
            hint: "Elastic Dropdown",
            animationType: DropdownAnimationType.elastic,
          ),
          // ),
          // Padding(
          //   padding: const EdgeInsets.all(8.0),
          //   child:
          AnimatedDropDown(
            items: dropDownItems,
            hint: "Flip Dropdown",
            animationType: DropdownAnimationType.flip,
          ),
          // ),
        ],
      ),
    );
  }
}

// Define the DropdownAnimationType enum
enum DropdownAnimationType { elastic, flip }

class AnimatedDropDown extends StatefulWidget {
  final List<String> items;
  final String hint;
  final DropdownAnimationType animationType;
  final ValueChanged<String>? onItemSelected;
  const AnimatedDropDown({
    super.key,
    required this.items,
    required this.hint,
    required this.animationType,
    this.onItemSelected,
  });

  @override
  State<AnimatedDropDown> createState() => _AnimatedDropDownState();
}

class _AnimatedDropDownState extends State<AnimatedDropDown>
    with TickerProviderStateMixin {
  bool _isOpen = false;
  late AnimationController _controller;
  late Animation<double> _rotationAnimation;
  String? _selectedItem;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 500),
    );
    _selectedItem = widget.hint;
    _rotationAnimation = Tween<double>(
      begin: 0.0,
      end: 0.25,
    ).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void toggle() {
    setState(() {
      _isOpen = !_isOpen;
      if (_isOpen) {
        // if (widget.animationType == DropdownAnimationType.elastic) {
        //   _controller.forward();
        // } else {
        _controller.forward();
        // }
      } else {
        _controller.reverse();
      }
    });
  }

  void _onItemSelected(String item) {
    setState(() {
      _selectedItem = item;
      _isOpen = true;
    });
    _controller.reverse();
    widget.onItemSelected?.call(item);
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        GestureDetector(
          onTap: toggle,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            decoration: BoxDecoration(
              color: Colors.white.withAlpha(100),
              border: Border.all(color: Colors.blue.shade200),
              borderRadius: BorderRadius.only(
                topLeft: Radius.circular(20),
                bottomRight: Radius.circular(20),
              ),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  _selectedItem ?? widget.hint,
                  style: TextStyle(fontSize: 16),
                ),
                SizedBox(width: 10),
                RotationTransition(
                  turns: _rotationAnimation,
                  child: Icon(Icons.keyboard_arrow_down),
                ),
              ],
            ),
          ),
        ),

        SizedBox(height: 10),
        if (widget.animationType == DropdownAnimationType.elastic)
          _buildElasticMenu(context)
        else if (widget.animationType == DropdownAnimationType.flip)
          _buildFlipMenu(context),
      ],
    );
  }

  Widget _buildElasticMenu(BuildContext context) {
    return SizeTransition(
      sizeFactor: CurvedAnimation(
        parent: _controller,
        curve: Interval(0.0, 1.0, curve: Curves.elasticOut),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white.withAlpha(100),
          border: Border.all(color: Colors.blue.shade200),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20),
            bottomRight: Radius.circular(20),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: widget.items
              .map(
                (item) => ListTile(
                  title: Text(item),
                  onTap: () => _onItemSelected(item),
                ),
              )
              .toList(),
        ),
      ),
    );
  }

  Widget _buildFlipMenu(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        final angle = (1 - _controller.value.clamp(0.0, 1.0)) * pi / 2;
        return Transform(
          transform: Matrix4.identity()
            ..setEntry(3, 2, 0.001)
            ..rotateX(angle),
          child: Opacity(opacity: _controller.value, child: child),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          color: Colors.white.withAlpha(100),

          border: Border.all(color: Colors.blue.shade200),
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(20),
            bottomRight: Radius.circular(20),
          ),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: widget.items
              .map(
                (item) => ListTile(
                  title: Text(item),
                  onTap: () => _onItemSelected(item),
                ),
              )
              .toList(),
        ),
      ),
    );
  }
}
